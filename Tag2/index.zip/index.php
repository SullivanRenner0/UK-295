<?php
include("AutoLoader.php");
AutoLoader::register();
// controller.php?action=users
// controller.php?action=artikel
$namespace = $_GET["namespace"] ?? "";
$action = $_GET["action"] ?? "";
$method = $_GET["method"] ?? "";
$param = $_GET["param"] ?? null;

if ($action != "" && $method != "")
{
    $class = "$namespace\\".$action;
    // $app = new $class();
    // $app->$method();
    $app = new $class($method, $param);
}
?>